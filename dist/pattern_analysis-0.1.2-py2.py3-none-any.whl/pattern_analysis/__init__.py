"""Top-level package for pattern_analysis."""

__author__ = """Anni Liu"""
__email__ = 'anni.liu009@gmail.com'
__version__ = '0.1.2'
