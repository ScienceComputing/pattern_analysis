=====
Usage
=====

To use pattern_analysis in a project::

    import pattern_analysis
