=======
History
=======

0.1.1 (2023-12-17)
------------------

* Restructure the pattern analysis package using cookiecutter-pypackage.

0.1.0 (2023-12-12)
------------------

* First release on PyPI.
